USAGE
-------
Use Run.bat to start the server

INSTALL
--------
* Place all files in the same folder as minecraft_server.jar